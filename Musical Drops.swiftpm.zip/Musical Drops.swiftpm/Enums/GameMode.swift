//
//  File.swift
//  
//
//  Created by Archer Gardiner-Sheridan on 15/4/2023.
//

import Foundation

enum GameMode {
    case edit
    case drawLines
    case createDropper
    case delete
}
